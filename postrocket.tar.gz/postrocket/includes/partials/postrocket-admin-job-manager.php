<?php
/**
 * Admin job manager page partial.
 *
 * @since      1.0.0
 * @package    PostRocket
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Initialize classes
$location_manager = new PostRocket_Location_Manager();
$api = new PostRocket_API();

// Check if API key is set
$api_key_set = $api->validate_api_key();

// Get location lists
$location_lists = $location_manager->get_all_location_lists();

// Get jobs
global $wpdb;
$jobs_query = "
    SELECT p.ID, p.post_title
    FROM {$wpdb->posts} p
    WHERE p.post_type = 'job_listing'
    AND p.post_status = 'publish'
    ORDER BY p.post_title ASC
";
$jobs = $wpdb->get_results($jobs_query);

// Get companies
$companies_query = "
    SELECT DISTINCT pm.meta_value as company_id, pm2.meta_value as company_name
    FROM {$wpdb->postmeta} pm
    JOIN {$wpdb->postmeta} pm2 ON pm.post_id = pm2.post_id
    WHERE pm.meta_key = '_company_id' 
    AND pm2.meta_key = '_company_name'
    AND pm.meta_value != ''
    ORDER BY pm2.meta_value ASC
";
$companies = $wpdb->get_results($companies_query);
?>

<div class="wrap postrocket-job-manager">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <?php if (!$api_key_set) : ?>
        <div class="notice notice-error">
            <p>
                <strong>API Key Required:</strong> 
                Please <a href="<?php echo esc_url(admin_url('admin.php?page=postrocket-settings')); ?>">set your API key</a> before using the job duplicator.
            </p>
        </div>
    <?php endif; ?>
    
    <div class="postrocket-card">
        <h2>Job Duplicator</h2>
        
        <form id="postrocket-job-duplicator-form" class="postrocket-form">
            <div class="postrocket-form-section">
                <h3>Step 1: Select Job</h3>
                <div class="postrocket-form-row">
                    <label for="postrocket-job">Job:</label>
                    <select id="postrocket-job" name="job_id" required>
                        <option value="">Select a job</option>
                        <?php foreach ($jobs as $job) : ?>
                            <option value="<?php echo esc_attr($job->ID); ?>">
                                <?php echo esc_html($job->post_title); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="postrocket-form-help">Select the job you want to duplicate.</p>
                </div>
                
                <div class="postrocket-form-row">
                    <label for="postrocket-company">Company:</label>
                    <select id="postrocket-company" name="company_id" required>
                        <option value="">Select a company</option>
                        <?php foreach ($companies as $company) : ?>
                            <option value="<?php echo esc_attr($company->company_id); ?>">
                                <?php echo esc_html($company->company_name); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="postrocket-form-help">Select the company associated with this job.</p>
                </div>
            </div>
            
            <div class="postrocket-form-section">
                <h3>Step 2: Choose Mode</h3>
                <div class="postrocket-form-row">
                    <div class="postrocket-radio-group">
                        <label>
                            <input type="radio" name="mode" value="manual" checked> 
                            Manual Mode (Enter locations)
                        </label>
                        <label>
                            <input type="radio" name="mode" value="auto" <?php echo empty($location_lists) ? 'disabled' : ''; ?>> 
                            Auto Mode (Select location list)
                        </label>
                    </div>
                    <p class="postrocket-form-help">Choose how you want to specify locations.</p>
                </div>
            </div>
            
            <div class="postrocket-form-section" id="postrocket-manual-mode">
                <h3>Step 3: Enter Locations</h3>
                <div class="postrocket-form-row">
                    <label for="postrocket-locations">Locations:</label>
                    <textarea id="postrocket-locations" name="locations" rows="5" placeholder="Enter locations separated by commas" required></textarea>
                    <p class="postrocket-form-help">
                        Enter locations separated by commas. Maximum 50 locations for immediate processing, up to 500 for background processing.
                        <span id="postrocket-location-count">0</span> locations entered.
                    </p>
                </div>
            </div>
            
            <div class="postrocket-form-section" id="postrocket-auto-mode" style="display: none;">
                <h3>Step 3: Select Location List</h3>
                <div class="postrocket-form-row">
                    <label for="postrocket-list">Location List:</label>
                    <select id="postrocket-list" name="list_id">
                        <option value="">Select a location list</option>
                        <?php foreach ($location_lists as $list) : ?>
                            <option value="<?php echo esc_attr($list['id']); ?>">
                                <?php echo esc_html($list['name']); ?> (<?php echo esc_html($list['count']); ?> locations)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="postrocket-form-help">
                        Select a saved location list. <a href="<?php echo esc_url(admin_url('admin.php?page=postrocket-location-manager')); ?>">Manage location lists</a>
                    </p>
                </div>
            </div>
            
            <div class="postrocket-form-section">
                <h3>Step 4: Scheduling (Optional)</h3>
                <div class="postrocket-form-row">
                    <label for="postrocket-schedule">Schedule Date:</label>
                    <input type="text" id="postrocket-schedule" name="schedule_date" placeholder="Click to select a date" autocomplete="off">
                    <p class="postrocket-form-help">
                        Optional: Schedule jobs for future publishing. Leave blank to publish immediately.
                    </p>
                </div>
            </div>
            
            <div class="postrocket-form-actions">
                <button type="submit" class="button button-primary" <?php echo !$api_key_set ? 'disabled' : ''; ?>>
                    Duplicate Job
                </button>
                <div class="postrocket-spinner" style="display: none;"></div>
            </div>
        </form>
        
        <div id="postrocket-result" class="postrocket-result" style="display: none;">
            <h3>Results</h3>
            <div id="postrocket-result-content"></div>
        </div>
    </div>
</div>

<script type="text/javascript">
    jQuery(document).ready(function($) {
        // Initialize datepicker
        $('#postrocket-schedule').datepicker({
            dateFormat: 'yy-mm-dd',
            minDate: 0
        });
        
        // Mode toggle
        $('input[name="mode"]').change(function() {
            if ($(this).val() === 'manual') {
                $('#postrocket-manual-mode').show();
                $('#postrocket-auto-mode').hide();
                $('#postrocket-locations').prop('required', true);
                $('#postrocket-list').prop('required', false);
            } else {
                $('#postrocket-manual-mode').hide();
                $('#postrocket-auto-mode').show();
                $('#postrocket-locations').prop('required', false);
                $('#postrocket-list').prop('required', true);
            }
        });
        
        // Location counter
        $('#postrocket-locations').on('input', function() {
            var text = $(this).val();
            var locations = text.split(',').filter(function(item) {
                return item.trim() !== '';
            });
            $('#postrocket-location-count').text(locations.length);
        });
        
        // Form submission
        $('#postrocket-job-duplicator-form').submit(function(e) {
            e.preventDefault();
            
            // Show spinner
            $('.postrocket-spinner').show();
            $('#postrocket-result').hide();
            
            // Get form data
            var formData = {
                'action': 'postrocket_duplicate_job',
                'nonce': postrocket_ajax.nonce,
                'job_id': $('#postrocket-job').val(),
                'company_id': $('#postrocket-company').val(),
                'mode': $('input[name="mode"]:checked').val(),
                'schedule_date': $('#postrocket-schedule').val()
            };
            
            // Add mode-specific data
            if (formData.mode === 'manual') {
                formData.locations = $('#postrocket-locations').val();
            } else {
                formData.list_id = $('#postrocket-list').val();
            }
            
            // Send AJAX request
            $.post(postrocket_ajax.ajax_url, formData, function(response) {
                $('.postrocket-spinner').hide();
                
                if (response.success) {
                    var result = response.data;
                    var content = '';
                    
                    if (result.mode === 'immediate') {
                        content += '<div class="notice notice-success"><p>' + 
                            'Successfully duplicated ' + result.duplicated + ' out of ' + result.total + ' jobs.' +
                            '</p></div>';
                        
                        if (result.duplicated > 0) {
                            content += '<table class="postrocket-table">' +
                                '<thead><tr><th>Location</th><th>Job ID</th></tr></thead>' +
                                '<tbody>';
                            
                            $.each(result.jobs, function(i, job) {
                                content += '<tr><td>' + job.location + '</td><td>' + job.job_id + '</td></tr>';
                            });
                            
                            content += '</tbody></table>';
                        }
                        
                        if (result.failed > 0) {
                            content += '<h4>Errors:</h4>';
                            
                            $.each(result.errors, function(i, error) {
                                content += '<p><strong>' + error.location + ':</strong> ' + error.error + '</p>';
                            });
                        }
                    } else if (result.mode === 'background') {
                        content += '<div class="notice notice-success"><p>' + 
                            'Job duplication added to background queue. ' + result.total + ' locations will be processed.' +
                            '</p></div>';
                        
                        content += '<p>You can monitor the progress on the <a href="' + 
                            '<?php echo esc_url(admin_url('admin.php?page=postrocket-background')); ?>' + 
                            '">Background Processing</a> page.</p>';
                    }
                    
                    $('#postrocket-result-content').html(content);
                } else {
                    var message = response.data && response.data.message ? response.data.message : 'An error occurred.';
                    $('#postrocket-result-content').html('<div class="notice notice-error"><p>' + message + '</p></div>');
                }
                
                $('#postrocket-result').show();
            }).fail(function() {
                $('.postrocket-spinner').hide();
                $('#postrocket-result-content').html('<div class="notice notice-error"><p>Request failed. Please try again.</p></div>');
                $('#postrocket-result').show();
            });
        });
    });
</script>