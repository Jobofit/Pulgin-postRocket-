=== PostRocket ===
Contributors: postrocketteam
Tags: jobs, job manager, job duplicator, job listings
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A powerful WordPress plugin for job duplication and management with advanced features.

== Description ==

PostRocket is a powerful WordPress plugin designed to enhance your job management capabilities. It allows you to duplicate job listings across multiple locations while maintaining all meta fields, categories, tags, and other job attributes.

**Key Features:**

* **Job Duplication**: Easily duplicate jobs across multiple locations with a single click
* **Company Selection**: Choose from existing companies or use the original job's company
* **Visibility Settings**: Control whether duplicated jobs appear in frontend queries
* **SEO Management**: Add noindex meta tags to duplicated jobs to prevent SEO duplication
* **Dashboard Statistics**: View comprehensive statistics about your job listings
* **Location Distribution**: See the distribution of jobs across different locations
* **Secure API Integration**: Securely store and manage API keys for enhanced functionality

== Installation ==

1. Upload the `postrocket` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to the 'PostRocket' menu in your WordPress admin panel

== Frequently Asked Questions ==

= Does this plugin require WP Job Manager? =

Yes, this plugin is designed to work with WP Job Manager and enhances its functionality.

= Can I hide duplicated jobs from search engines? =

Yes, you can enable the option to add noindex meta tags to duplicated jobs in the Visibility Settings tab.

= How many jobs can I duplicate at once? =

You can duplicate a job to multiple locations at once by entering comma-separated location names.

== Screenshots ==

1. Dashboard with statistics and recent jobs
2. Job Duplicator interface
3. Visibility Settings
4. API Settings

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
Initial release
