jQuery(document).ready(function($) {
    // Character counter for locations field
    $('#locations').on('input', function() {
        var currentLength = $(this).val().split(',').filter(function(item) {
            return item.trim() !== '';
        }).length;
        
        $('#locations-counter').text(currentLength);
        
        // Change color based on count
        if (currentLength > 50) {
            $('#locations-counter').css('color', 'red');
            // Show warning if over limit
            if (!$('.postrocket-location-limit-warning').length) {
                $(this).after('<div class="postrocket-location-limit-warning postrocket-notification postrocket-notification-warning">You cannot add more than 50 locations to a single list.</div>');
            }
        } else if (currentLength > 40) {
            $('#locations-counter').css('color', 'orange');
            $('.postrocket-location-limit-warning').remove();
        } else {
            $('#locations-counter').css('color', '');
            $('.postrocket-location-limit-warning').remove();
        }
    });
    
    // Function to show notifications within the plugin UI
    function showNotification(message, type) {
        var notificationClass = 'postrocket-notification-' + type;
        var notification = '<div class="postrocket-notification ' + notificationClass + '">' + message + '</div>';
        
        // Add notification to the notification area
        $('#postrocket-notifications').html(notification);
        
        // Scroll to notification
        $('html, body').animate({
            scrollTop: $('#postrocket-notifications').offset().top - 50
        }, 500);
        
        // Auto-hide after 5 seconds
        setTimeout(function() {
            $('#postrocket-notifications').find('.postrocket-notification').fadeOut(500, function() {
                $(this).remove();
            });
        }, 5000);
    }
    
    // Function to update job duplicator mode display
    function updateJobDuplicatorMode(mode) {
        if (mode === 'manual') {
            $('.postrocket-manual-mode').show();
            $('.postrocket-auto-mode').hide();
        } else {
            $('.postrocket-manual-mode').hide();
            $('.postrocket-auto-mode').show();
        }
    }
    
    // Function to add location list to table
    function addLocationListToTable(key, list) {
        var $table = $('#postrocket-saved-locations-table');
        
        // If table doesn't exist yet, create it
        if ($table.length === 0) {
            var tableHtml = '<table id="postrocket-saved-locations-table" class="widefat striped">' +
                '<thead><tr>' +
                '<th>Name</th>' +
                '<th>Locations</th>' +
                '<th>Actions</th>' +
                '</tr></thead>' +
                '<tbody></tbody>' +
                '</table>';
            
            $('.postrocket-saved-locations').html(tableHtml);
            $table = $('#postrocket-saved-locations-table');
        }
        
        // Create row HTML
        var locationsText = list.locations.join(', ');
        var rowHtml = '<tr data-key="' + key + '">' +
            '<td>' + list.name + '</td>' +
            '<td>' + locationsText + '</td>' +
            '<td><button type="button" class="button button-small postrocket-delete-location-list">Delete</button></td>' +
            '</tr>';
        
        // Add row to table
        $table.find('tbody').append(rowHtml);
    }
    
    // Location Form Submission
    $('#postrocket-location-manager-form').on('submit', function(e) {
        e.preventDefault();
        
        // Validate form
        var locationListName = $('#location_list_name').val();
        var locations = $('#locations').val();
        
        if (!locationListName) {
            showNotification('Please enter a name for the location list.', 'error');
            return false;
        }
        
        if (!locations) {
            showNotification('Please enter at least one location.', 'error');
            return false;
        }
        
        // Check location count
        var locationCount = locations.split(',').filter(function(item) {
            return item.trim() !== '';
        }).length;
        
        if (locationCount > 50) {
            showNotification('You cannot add more than 50 locations to a single list.', 'error');
            return false;
        }
        
        // Disable submit button
        $(this).find('button[type="submit"]').prop('disabled', true).text('Saving...');
        
        // Prepare data
        var formData = $(this).serialize();
        
        // Send AJAX request
        $.ajax({
            url: postrocket_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'postrocket_save_location_list',
                nonce: postrocket_ajax.nonce,
                location_list_name: locationListName,
                locations: locations
            },
            dataType: 'json',
            success: function(response) {
                // Re-enable submit button
                $('#postrocket-location-manager-form').find('button[type="submit"]').prop('disabled', false).text('Save Locations');
                
                if (response.success) {
                    // Show success message
                    showNotification(response.data.message, 'success');
                    
                    // Reset form
                    $('#location_list_name').val('');
                    $('#locations').val('');
                    $('#locations-counter').text('0');
                    
                    // Add new location list to table
                    addLocationListToTable(response.data.key, response.data.list);
                } else {
                    // Show error message
                    showNotification(response.data.message, 'error');
                }
            },
            error: function() {
                // Re-enable submit button
                $('#postrocket-location-manager-form').find('button[type="submit"]').prop('disabled', false).text('Save Locations');
                
                // Show error message
                showNotification('An error occurred. Please try again.', 'error');
            }
        });
    });
    
    // Delete Location List
    $(document).on('click', '.postrocket-delete-location-list', function() {
        var key = $(this).closest('tr').data('key');
        var name = $(this).closest('tr').find('td:first').text();
        
        if (!confirm('Are you sure you want to delete the location list "' + name + '"? This action cannot be undone.')) {
            return;
        }
        
        // Disable button
        $(this).prop('disabled', true).text('Deleting...');
        
        var $row = $(this).closest('tr');
        
        // Send AJAX request
        $.ajax({
            url: postrocket_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'postrocket_delete_location_list',
                nonce: postrocket_ajax.nonce,
                key: key
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Show success message
                    showNotification(response.data.message, 'success');
                    
                    // Remove row from table
                    $row.fadeOut(300, function() {
                        $(this).remove();
                        
                        // If no more rows, show "no lists" message
                        if ($('#postrocket-saved-locations-table tbody tr').length === 0) {
                            $('#postrocket-saved-locations-table').replaceWith('<p>No location lists saved yet.</p>');
                        }
                    });
                } else {
                    // Re-enable button
                    $row.find('.postrocket-delete-location-list').prop('disabled', false).text('Delete');
                    
                    // Show error message
                    showNotification(response.data.message, 'error');
                }
            },
            error: function() {
                // Re-enable button
                $row.find('.postrocket-delete-location-list').prop('disabled', false).text('Delete');
                
                // Show error message
                showNotification('An error occurred. Please try again.', 'error');
            }
        });
    });
    
    // Job Duplicator Mode Selection
    if ($('input[name="job-duplicator-mode"]').length) {
        // Initial state
        updateJobDuplicatorMode($('input[name="job-duplicator-mode"]:checked').val());
        
        // Mode change handler
        $('input[name="job-duplicator-mode"]').on('change', function() {
            updateJobDuplicatorMode($(this).val());
        });
    }
    
    // Location list selection handler
    $('#location_list_key').on('change', function() {
        // Get selected location list keys
        var selectedKeys = $(this).val();
        
        if (selectedKeys && selectedKeys.length > 0) {
            // Automatically fetch location data for selected lists
            $.ajax({
                url: postrocket_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'postrocket_get_location_list_data',
                    nonce: postrocket_ajax.nonce,
                    keys: selectedKeys
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success && response.data.locations && response.data.locations.length > 0) {
                        // Store the fetched locations for form submission
                        $('#location_list_key').data('fetched-locations', response.data.locations);
                    }
                }
            });
        }
    });
    
    // Job Duplicator Form Submission
    $('#postrocket-job-duplicator-form').on('submit', function(e) {
        e.preventDefault();
        
        // Validate form
        var jobId = $('#job_id').val();
        var mode = $('input[name="job-duplicator-mode"]:checked').val() || 'manual';
        var locations = '';
        var locationListKey = '';
        
        if (!jobId) {
            showNotification('Please select a base job.', 'error');
            return false;
        }
        
        if (mode === 'manual') {
            locations = $('#locations').val();
            if (!locations) {
                showNotification('Please enter at least one location.', 'error');
                return false;
            }
        } else {
            locationListKey = $('#location_list_key').val();
            if (!locationListKey || locationListKey.length === 0) {
                showNotification('Please select at least one location list in Auto Mode.', 'error');
                return false;
            }
            
            // Get fetched locations from data attribute
            var fetchedLocations = $('#location_list_key').data('fetched-locations');
            
            // Only show error if fetched list is empty or invalid
            if (!fetchedLocations || fetchedLocations.length === 0) {
                showNotification('Please enter at least one location.', 'error');
                return false;
            }
            
            // Use the fetched locations
            locations = fetchedLocations.join(', ');
        }
        
        // Show loading animation
        $('#postrocket-loading-container').show();
        $('#postrocket-loading-text').text('Starting job duplication...');
        
        // Disable submit button
        $(this).find('button[type="submit"]').prop('disabled', true).text('Processing...');
        
        // Prepare data
        var formData = {
            action: 'postrocket_duplicate_jobs',
            nonce: postrocket_ajax.nonce,
            job_id: jobId,
            company_id: $('#company_id').val(),
            mode: mode
        };
        
        if (mode === 'manual') {
            formData.locations = locations;
        } else {
            formData.location_list_key = locationListKey;
            formData.locations = locations; // Add the fetched locations
        }
        
        // Send AJAX request
        $.ajax({
            url: postrocket_ajax.ajax_url,
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                // Hide loading animation
                $('#postrocket-loading-container').hide();
                
                // Re-enable submit button
                $('#postrocket-job-duplicator-form').find('button[type="submit"]').prop('disabled', false).text('Duplicate Jobs');
                
                if (response.success) {
                    // Show success message
                    showNotification(response.data.message, 'success');
                    
                    // Reset form
                    if (mode === 'manual') {
                        $('#locations').val('');
                        $('#locations-counter').text('0');
                    }
                } else {
                    // Show error message
                    showNotification(response.data.message, 'error');
                }
            },
            error: function() {
                // Hide loading animation
                $('#postrocket-loading-container').hide();
                
                // Re-enable submit button
                $('#postrocket-job-duplicator-form').find('button[type="submit"]').prop('disabled', false).text('Duplicate Jobs');
                
                // Show error message
                showNotification('An error occurred. Please try again.', 'error');
            }
        });
    });
    
    // Visibility Settings Form Submission
    $('#postrocket-visibility-settings-form').on('submit', function(e) {
        e.preventDefault();
        
        // Prepare data
        var hideDuplicates = $('#hide_duplicates').is(':checked') ? 'yes' : 'no';
        var noindexDuplicates = $('#noindex_duplicates').is(':checked') ? 'yes' : 'no';
        
        // Disable submit button
        $(this).find('button[type="submit"]').prop('disabled', true).text('Saving...');
        
        // Send AJAX request
        $.ajax({
            url: postrocket_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'postrocket_save_settings',
                nonce: postrocket_ajax.nonce,
                hide_duplicates: hideDuplicates,
                noindex_duplicates: noindexDuplicates
            },
            dataType: 'json',
            success: function(response) {
                // Re-enable submit button
                $('#postrocket-visibility-settings-form').find('button[type="submit"]').prop('disabled', false).text('Save Settings');
                
                if (response.success) {
                    // Show success message
                    showNotification(response.data.message, 'success');
                } else {
                    // Show error message
                    showNotification(response.data.message, 'error');
                }
            },
            error: function() {
                // Re-enable submit button
                $('#postrocket-visibility-settings-form').find('button[type="submit"]').prop('disabled', false).text('Save Settings');
                
                // Show error message
                showNotification('An error occurred. Please try again.', 'error');
            }
        });
    });
    
    // API Settings Form Submission
    $('#postrocket-api-settings-form').on('submit', function(e) {
        e.preventDefault();
        
        // Prepare data
        var apiKey = $('#api_key').val();
        
        // Disable submit button
        $(this).find('button[type="submit"]').prop('disabled', true).text('Saving...');
        
        // Send AJAX request
        $.ajax({
            url: postrocket_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'postrocket_save_api_key',
                nonce: postrocket_ajax.nonce,
                api_key: apiKey
            },
            dataType: 'json',
            success: function(response) {
                // Re-enable submit button
                $('#postrocket-api-settings-form').find('button[type="submit"]').prop('disabled', false).text('Save API Key');
                
                if (response.success) {
                    // Show success message
                    showNotification(response.data.message, 'success');
                    
                    // Update API status
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                } else {
                    // Show error message
                    showNotification(response.data.message, 'error');
                }
            },
            error: function() {
                // Re-enable submit button
                $('#postrocket-api-settings-form').find('button[type="submit"]').prop('disabled', false).text('Save API Key');
                
                // Show error message
                showNotification('An error occurred. Please try again.', 'error');
            }
        });
    });
    
    // API Key Verification
    $('#verify-api-key').on('click', function(e) {
        e.preventDefault();
        
        // Disable verify button
        $(this).prop('disabled', true).text('Verifying...');
        
        // Clear previous messages
        $('#postrocket-api-message').empty();
        
        // Send AJAX request
        $.ajax({
            url: postrocket_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'postrocket_verify_api_key',
                nonce: postrocket_ajax.nonce
            },
            dataType: 'json',
            success: function(response) {
                // Re-enable verify button
                $('#verify-api-key').prop('disabled', false).text('Verify API Key');
                
                if (response.success) {
                    // Show success message
                    $('#postrocket-api-message').html('<div class="postrocket-notification postrocket-notification-success">' + response.data.message + '</div>');
                } else {
                    // Show error message
                    $('#postrocket-api-message').html('<div class="postrocket-notification postrocket-notification-error">' + response.data.message + '</div>');
                }
            },
            error: function() {
                // Re-enable verify button
                $('#verify-api-key').prop('disabled', false).text('Verify API Key');
                
                // Show error message
                $('#postrocket-api-message').html('<div class="postrocket-notification postrocket-notification-error">An error occurred. Please try again.</div>');
            }
        });
    });
    
    // Bulk Operations - Delete Duplicate Jobs
    $('#delete-duplicate-jobs').on('click', function(e) {
        e.preventDefault();
        
        if (!confirm('Are you sure you want to delete all duplicate jobs? This action cannot be undone.')) {
            return;
        }
        
        // Disable button
        $(this).prop('disabled', true).text('Processing...');
        
        // Clear previous results
        $('#delete-duplicate-jobs-result').empty();
        
        // Send AJAX request
        $.ajax({
            url: postrocket_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'postrocket_delete_duplicate_jobs',
                nonce: postrocket_ajax.nonce
            },
            dataType: 'json',
            success: function(response) {
                // Re-enable button
                $('#delete-duplicate-jobs').prop('disabled', false).text('Delete All Duplicate Jobs');
                
                if (response.success) {
                    // Show success message
                    showNotification(response.data.message, 'success');
                    
                    // Update result
                    $('#delete-duplicate-jobs-result').html('<div class="postrocket-result postrocket-result-success">' + response.data.message + '</div>');
                } else {
                    // Show error message
                    showNotification(response.data.message, 'error');
                    
                    // Update result
                    $('#delete-duplicate-jobs-result').html('<div class="postrocket-result postrocket-result-error">' + response.data.message + '</div>');
                }
            },
            error: function() {
                // Re-enable button
                $('#delete-duplicate-jobs').prop('disabled', false).text('Delete All Duplicate Jobs');
                
                // Show error message
                showNotification('An error occurred. Please try again.', 'error');
                
                // Update result
                $('#delete-duplicate-jobs-result').html('<div class="postrocket-result postrocket-result-error">An error occurred. Please try again.</div>');
            }
        });
    });
    
    // Bulk Operations - Delete Expired Jobs
    $('#delete-expired-jobs').on('click', function(e) {
        e.preventDefault();
        
        if (!confirm('Are you sure you want to delete all expired jobs? This action cannot be undone.')) {
            return;
        }
        
        // Disable button
        $(this).prop('disabled', true).text('Processing...');
        
        // Clear previous results
        $('#delete-expired-jobs-result').empty();
        
        // Send AJAX request
        $.ajax({
            url: postrocket_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'postrocket_delete_expired_jobs',
                nonce: postrocket_ajax.nonce
            },
            dataType: 'json',
            success: function(response) {
                // Re-enable button
                $('#delete-expired-jobs').prop('disabled', false).text('Delete All Expired Jobs');
                
                if (response.success) {
                    // Show success message
                    showNotification(response.data.message, 'success');
                    
                    // Update result
                    $('#delete-expired-jobs-result').html('<div class="postrocket-result postrocket-result-success">' + response.data.message + '</div>');
                } else {
                    // Show error message
                    showNotification(response.data.message, 'error');
                    
                    // Update result
                    $('#delete-expired-jobs-result').html('<div class="postrocket-result postrocket-result-error">' + response.data.message + '</div>');
                }
            },
            error: function() {
                // Re-enable button
                $('#delete-expired-jobs').prop('disabled', false).text('Delete All Expired Jobs');
                
                // Show error message
                showNotification('An error occurred. Please try again.', 'error');
                
                // Update result
                $('#delete-expired-jobs-result').html('<div class="postrocket-result postrocket-result-error">An error occurred. Please try again.</div>');
            }
        });
    });
    
    // Bulk Operations - Delete All Jobs
    $('#delete-all-jobs').on('click', function(e) {
        e.preventDefault();
        
        if (!confirm('Are you sure you want to delete ALL jobs? This action cannot be undone.')) {
            return;
        }
        
        if (!confirm('This will delete ALL jobs, including non-duplicated jobs. Are you absolutely sure?')) {
            return;
        }
        
        // Disable button
        $(this).prop('disabled', true).text('Processing...');
        
        // Clear previous results
        $('#delete-all-jobs-result').empty();
        
        // Send AJAX request
        $.ajax({
            url: postrocket_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'postrocket_delete_all_jobs',
                nonce: postrocket_ajax.nonce
            },
            dataType: 'json',
            success: function(response) {
                // Re-enable button
                $('#delete-all-jobs').prop('disabled', false).text('Delete ALL Jobs');
                
                if (response.success) {
                    // Show success message
                    showNotification(response.data.message, 'success');
                    
                    // Update result
                    $('#delete-all-jobs-result').html('<div class="postrocket-result postrocket-result-success">' + response.data.message + '</div>');
                } else {
                    // Show error message
                    showNotification(response.data.message, 'error');
                    
                    // Update result
                    $('#delete-all-jobs-result').html('<div class="postrocket-result postrocket-result-error">' + response.data.message + '</div>');
                }
            },
            error: function() {
                // Re-enable button
                $('#delete-all-jobs').prop('disabled', false).text('Delete ALL Jobs');
                
                // Show error message
                showNotification('An error occurred. Please try again.', 'error');
                
                // Update result
                $('#delete-all-jobs-result').html('<div class="postrocket-result postrocket-result-error">An error occurred. Please try again.</div>');
            }
        });
    });
});
