// API Key Popup HTML
function createApiKeyPopup() {
    var popupHtml = '<div id="postrocket-api-key-popup" class="postrocket-popup">' +
        '<div class="postrocket-popup-content">' +
        '<div class="postrocket-popup-header">' +
        '<h2>API Key Required</h2>' +
        '</div>' +
        '<div class="postrocket-popup-body">' +
        '<p>PostRocket requires an API key to function properly. Please enter your API key to enable all features.</p>' +
        '<div class="postrocket-form-row">' +
        '<label for="popup-api-key">API Key</label>' +
        '<input type="text" id="popup-api-key" name="popup-api-key" class="regular-text">' +
        '</div>' +
        '</div>' +
        '<div class="postrocket-popup-footer">' +
        '<button type="button" id="add-api-key-now" class="button button-primary">Add API Key Now</button>' +
        '<button type="button" id="add-api-key-later" class="button button-secondary">Later</button>' +
        '</div>' +
        '</div>' +
        '</div>';
    
    return popupHtml;
}

// Warning Bar HTML
function createApiKeyWarningBar() {
    var warningHtml = '<div id="postrocket-api-key-warning" class="postrocket-warning-bar">' +
        '<span>API Key Required to Enable Features.</span>' +
        '<button type="button" id="add-api-key-button" class="button button-small">Add Key</button>' +
        '</div>';
    
    return warningHtml;
}

// Check if API key is set
function checkApiKey() {
    // Send AJAX request to check API key
    $.ajax({
        url: postrocket_ajax.ajax_url,
        type: 'POST',
        data: {
            action: 'postrocket_check_api_key',
            nonce: postrocket_ajax.nonce
        },
        dataType: 'json',
        success: function(response) {
            if (!response.success) {
                // Check if popup was already shown in this session
                if (!sessionStorage.getItem('postrocket_api_popup_shown')) {
                    // Show API key popup
                    $('body').append(createApiKeyPopup());
                    $('#postrocket-api-key-popup').fadeIn(300);
                    
                    // Mark popup as shown in this session
                    sessionStorage.setItem('postrocket_api_popup_shown', 'true');
                }
                
                // Always show warning bar if API key is missing
                if (!$('#postrocket-api-key-warning').length) {
                    $('.postrocket-admin').prepend(createApiKeyWarningBar());
                }
                
                // Disable all functionality except API settings
                disablePluginFunctionality();
            }
        }
    });
}

// Disable plugin functionality
function disablePluginFunctionality() {
    // Only allow access to API settings tab
    if ($('.nav-tab-wrapper').length && !$('.nav-tab-wrapper a[href*="api-settings"]').hasClass('nav-tab-active')) {
        $('.postrocket-tab-content form').find('input, select, textarea, button').prop('disabled', true);
        $('.postrocket-tab-content form').append('<div class="postrocket-disabled-overlay"><p>API Key required to use this feature. <a href="#" class="add-api-key-link">Add API Key</a></p></div>');
    }
}

// Initialize API key check
$(document).ready(function() {
    // Check API key on page load
    checkApiKey();
    
    // Add API Key Now button click handler
    $(document).on('click', '#add-api-key-now', function() {
        var apiKey = $('#popup-api-key').val();
        
        if (!apiKey) {
            // Show error message
            $('.postrocket-popup-body').append('<div class="postrocket-notification postrocket-notification-error">Please enter an API key.</div>');
            return;
        }
        
        // Disable button
        $(this).prop('disabled', true).text('Saving...');
        
        // Send AJAX request
        $.ajax({
            url: postrocket_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'postrocket_save_api_key',
                nonce: postrocket_ajax.nonce,
                api_key: apiKey
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Show success message
                    $('.postrocket-popup-body').append('<div class="postrocket-notification postrocket-notification-success">' + response.data.message + '</div>');
                    
                    // Close popup after delay
                    setTimeout(function() {
                        $('#postrocket-api-key-popup').fadeOut(300, function() {
                            $(this).remove();
                            location.reload();
                        });
                    }, 1500);
                } else {
                    // Re-enable button
                    $('#add-api-key-now').prop('disabled', false).text('Add API Key Now');
                    
                    // Show error message
                    $('.postrocket-popup-body').append('<div class="postrocket-notification postrocket-notification-error">' + response.data.message + '</div>');
                }
            },
            error: function() {
                // Re-enable button
                $('#add-api-key-now').prop('disabled', false).text('Add API Key Now');
                
                // Show error message
                $('.postrocket-popup-body').append('<div class="postrocket-notification postrocket-notification-error">An error occurred. Please try again.</div>');
            }
        });
    });
    
    // Later button click handler
    $(document).on('click', '#add-api-key-later', function() {
        // Close popup
        $('#postrocket-api-key-popup').fadeOut(300, function() {
            $(this).remove();
        });
    });
    
    // Add API Key button in warning bar click handler
    $(document).on('click', '#add-api-key-button, .add-api-key-link', function(e) {
        e.preventDefault();
        
        // Navigate to API settings tab
        window.location.href = '?page=postrocket-job-manager&tab=api-settings';
    });
});
