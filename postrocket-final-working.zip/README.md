# PostRocket Plugin Documentation

## Overview
PostRocket is a WordPress plugin designed to help you duplicate job listings across multiple locations. This documentation covers the updated features and functionality of the plugin.

## Features

### 1. Job Duplicator
- Duplicate a single job listing across multiple locations
- Two modes available:
  - **Manual Mode**: Enter locations manually (comma-separated)
  - **Auto Mode**: Select from saved location lists
- Maximum 50 locations allowed per duplication operation
- Performance optimized to process 1-10 jobs/second

### 2. Location Manager
- Create and manage named lists of locations
- Each list can contain up to 50 locations
- Locations are automatically trimmed and deduplicated
- Saved location lists can be reused across the plugin

### 3. Dashboard
- View total jobs across all locations
- Location distribution chart shows job distribution by location

### 4. Visibility Settings
- Option to hide duplicate jobs from frontend listings
- Option to add noindex meta tags to duplicate job pages

### 5. API Key Management
- Required for plugin functionality
- Securely stored and encrypted
- Domain-restricted to prevent unauthorized use

## Usage Instructions

### Setting Up API Key
1. Navigate to Job Manager > API Settings
2. Enter your API key in the provided field
3. Click "Save API Key"
4. If you don't have an API key yet, you can click "Later" and add it when ready
5. Note: Most plugin features are disabled until a valid API key is provided

### Creating Location Lists
1. Navigate to Location Manager
2. Enter a name for your location list
3. Enter up to 50 locations separated by commas
4. Click "Save Locations"
5. Your location list will appear in the table below

### Duplicating Jobs
1. Navigate to Job Manager > Job Duplicator
2. Select the base job you want to duplicate
3. Optionally select a company (or use the original company)
4. Choose a mode:
   - **Manual Mode**: Enter locations manually (up to 50)
   - **Auto Mode**: Select from your saved location lists
5. Click "Duplicate Jobs"
6. The plugin will create duplicate jobs for each location

### Managing Visibility
1. Navigate to Job Manager > Visibility Settings
2. Choose whether to hide duplicate jobs from frontend listings
3. Choose whether to add noindex meta tags to duplicate job pages
4. Click "Save Settings"

## Limitations
- Maximum 50 locations per duplication operation
- Maximum 50 locations per saved location list
- API key required for full functionality

## Troubleshooting
- If you see a warning bar at the top of the plugin, you need to add your API key
- If you encounter errors during job duplication, check that you haven't exceeded the 50 location limit
- Ensure your API key is valid and properly entered

## Support
For additional support, please visit https://skillonzo.co.in
