<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @since      1.0.0
 * @package    PostRocket
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Delete plugin options
delete_option( 'postrocket_hide_duplicates' );
delete_option( 'postrocket_noindex_duplicates' );
delete_option( 'postrocket_api_key' );

// Delete transients
global $wpdb;
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '%postrocket_duplicate_%'" );
