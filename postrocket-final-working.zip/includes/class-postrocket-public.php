<?php
/**
 * The public-facing functionality of the plugin.
 *
 * @since      1.0.0
 * @package    PostRocket
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * The public-facing functionality of the plugin.
 */
class PostRocket_Public {

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Add hooks
        add_action( 'wp', array( $this, 'maybe_hide_duplicate_jobs' ) );
        add_action( 'wp_head', array( $this, 'maybe_add_noindex_meta' ) );
    }

    /**
     * Maybe hide duplicate jobs from frontend.
     *
     * @since    1.0.0
     */
    public function maybe_hide_duplicate_jobs() {
        // Check if we should hide duplicate jobs
        $hide_duplicates = get_option( 'postrocket_hide_duplicates', 'no' );
        
        if ( 'yes' === $hide_duplicates && !is_admin() ) {
            add_filter( 'pre_get_posts', array( $this, 'exclude_duplicate_jobs' ) );
        }
    }

    /**
     * Exclude duplicate jobs from query.
     *
     * @since    1.0.0
     * @param    WP_Query $query The WP_Query instance.
     * @return   WP_Query        The modified query.
     */
    public function exclude_duplicate_jobs( $query ) {
        // Only modify job listing queries
        if ( ! is_admin() && $query->is_main_query() && 
             ( is_post_type_archive( 'job_listing' ) || is_tax( 'job_listing_category' ) || is_tax( 'job_listing_type' ) ) ) {
            
            // Add meta query to exclude duplicated jobs
            $meta_query = $query->get( 'meta_query' );
            if ( ! is_array( $meta_query ) ) {
                $meta_query = array();
            }
            
            $meta_query[] = array(
                'relation' => 'OR',
                array(
                    'key'     => '_postrocket_duplicated',
                    'compare' => 'NOT EXISTS',
                ),
                array(
                    'key'     => '_postrocket_duplicated',
                    'value'   => '1',
                    'compare' => '!=',
                ),
            );
            
            $query->set( 'meta_query', $meta_query );
        }
        
        return $query;
    }

    /**
     * Maybe add noindex meta tag to duplicate jobs.
     *
     * @since    1.0.0
     */
    public function maybe_add_noindex_meta() {
        // Check if we should add noindex meta tag
        $noindex_duplicates = get_option( 'postrocket_noindex_duplicates', 'no' );
        
        if ( 'yes' === $noindex_duplicates && is_singular( 'job_listing' ) ) {
            global $post;
            
            // Check if this is a duplicated job
            $is_duplicated = get_post_meta( $post->ID, '_postrocket_duplicated', true );
            
            if ( '1' === $is_duplicated ) {
                echo '<meta name="robots" content="noindex,nofollow" />' . "\n";
            }
        }
    }
}
