<?php
/**
 * AJAX handlers for the plugin.
 *
 * @since      1.0.0
 * @package    PostRocket
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * AJAX handler for getting location list data.
 * This function is defined outside the class to avoid initialization issues.
 */
function postrocket_get_location_list_data() {
    // Check nonce for security
    check_ajax_referer( 'postrocket_nonce', 'nonce' );

    // Check user permissions
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'postrocket' ) ) );
    }

    // Get location keys from request
    $keys = isset( $_POST['keys'] ) ? (array) $_POST['keys'] : array();
    
    if ( empty( $keys ) ) {
        wp_send_json_error( array( 'message' => __( 'No location lists selected.', 'postrocket' ) ) );
    }
    
    // Get location manager instance
    $location_manager = new PostRocket_Location_Manager();
    
    // Get all locations from selected lists
    $all_locations = array();
    foreach ( $keys as $key ) {
        $location_list = $location_manager->get_location_list( sanitize_text_field( $key ) );
        if ( $location_list && !empty( $location_list['locations'] ) ) {
            $all_locations = array_merge( $all_locations, $location_list['locations'] );
        }
    }
    
    // Remove duplicates
    $all_locations = array_unique( $all_locations );
    
    wp_send_json_success( array(
        'message' => sprintf( __( 'Found %d locations.', 'postrocket' ), count( $all_locations ) ),
        'locations' => $all_locations
    ) );
}

// Register the function directly to avoid class initialization issues
add_action('wp_ajax_postrocket_get_location_list_data', 'postrocket_get_location_list_data');

/**
 * Class for handling AJAX requests.
 * This class is initialized by the loader to avoid activation issues.
 */
class PostRocket_AJAX {

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Empty constructor - hooks will be added by the loader
    }

    /**
     * Register AJAX hooks.
     * This method is called by the loader after WordPress is fully initialized.
     *
     * @since    1.0.0
     */
    public function register_hooks() {
        // Register AJAX actions
        add_action( 'wp_ajax_postrocket_save_location_list', array( $this, 'save_location_list' ) );
        add_action( 'wp_ajax_postrocket_delete_location_list', array( $this, 'delete_location_list' ) );
        add_action( 'wp_ajax_postrocket_duplicate_job', array( $this, 'duplicate_job' ) );
        add_action( 'wp_ajax_postrocket_save_api_key', array( $this, 'save_api_key' ) );
        add_action( 'wp_ajax_postrocket_verify_api_key', array( $this, 'verify_api_key' ) );
        add_action( 'wp_ajax_postrocket_delete_duplicate_jobs', array( $this, 'delete_duplicate_jobs' ) );
        add_action( 'wp_ajax_postrocket_check_api_key', array( $this, 'check_api_key' ) );
    }

    /**
     * Check if API key is set.
     *
     * @since    1.0.0
     */
    public function check_api_key() {
        // Check nonce
        if ( ! check_ajax_referer( 'postrocket_nonce', 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => __( 'Security check failed.', 'postrocket' ) ) );
        }

        // Check if API key is set
        $api = new PostRocket_API();
        $api_key = $api->get_api_key();
        
        if ( empty( $api_key ) ) {
            wp_send_json_error( array( 'message' => __( 'API key is not set.', 'postrocket' ) ) );
        } else {
            wp_send_json_success( array( 'message' => __( 'API key is set.', 'postrocket' ) ) );
        }
    }

    /**
     * Save location list.
     *
     * @since    1.0.0
     */
    public function save_location_list() {
        // Check nonce
        if ( ! check_ajax_referer( 'postrocket_nonce', 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => __( 'Security check failed.', 'postrocket' ) ) );
        }

        // Get form data
        $location_list_name = isset( $_POST['location_list_name'] ) ? sanitize_text_field( $_POST['location_list_name'] ) : '';
        $locations = isset( $_POST['locations'] ) ? sanitize_textarea_field( $_POST['locations'] ) : '';

        // Save location list
        $location_manager = new PostRocket_Location_Manager();
        $result = $location_manager->save_location_list( $location_list_name, $locations );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        } else {
            wp_send_json_success( array(
                'message' => $result['message'],
                'key'     => $result['key'],
                'list'    => $result['list'],
            ) );
        }
    }

    /**
     * Delete location list.
     *
     * @since    1.0.0
     */
    public function delete_location_list() {
        // Check nonce
        if ( ! check_ajax_referer( 'postrocket_nonce', 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => __( 'Security check failed.', 'postrocket' ) ) );
        }

        // Get key
        $key = isset( $_POST['key'] ) ? sanitize_text_field( $_POST['key'] ) : '';

        // Delete location list
        $location_manager = new PostRocket_Location_Manager();
        $result = $location_manager->delete_location_list( $key );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        } else {
            wp_send_json_success( array( 'message' => $result['message'] ) );
        }
    }

    /**
     * Duplicate job.
     *
     * @since    1.0.0
     */
    public function duplicate_job() {
        // Check nonce
        if ( ! check_ajax_referer( 'postrocket_nonce', 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => __( 'Security check failed.', 'postrocket' ) ) );
        }

        // Get form data
        $job_id = isset( $_POST['job_id'] ) ? absint( $_POST['job_id'] ) : 0;
        $company_id = isset( $_POST['company_id'] ) ? absint( $_POST['company_id'] ) : 0;
        $mode = isset( $_POST['mode'] ) ? sanitize_text_field( $_POST['mode'] ) : 'manual';
        $locations = isset( $_POST['locations'] ) ? sanitize_textarea_field( $_POST['locations'] ) : '';
        $location_list_key = isset( $_POST['location_list_key'] ) ? sanitize_text_field( $_POST['location_list_key'] ) : '';

        // Duplicate job
        $job_duplicator = new PostRocket_Job_Duplicator();
        
        if ( $mode === 'auto' ) {
            // Get locations from location list
            $location_manager = new PostRocket_Location_Manager();
            $location_list = $location_manager->get_location_list( $location_list_key );
            
            if ( ! $location_list ) {
                wp_send_json_error( array( 'message' => __( 'Location list not found.', 'postrocket' ) ) );
            }
            
            $locations_string = implode( ', ', $location_list['locations'] );
            $result = $job_duplicator->duplicate_jobs( $job_id, $company_id, $locations_string );
        } else {
            $result = $job_duplicator->duplicate_jobs( $job_id, $company_id, $locations );
        }

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        } else {
            wp_send_json_success( array(
                'message'      => sprintf( __( 'Job duplicated successfully to %d locations.', 'postrocket' ), count( $result ) ),
                'created_jobs' => $result,
            ) );
        }
    }

    /**
     * Save API key.
     *
     * @since    1.0.0
     */
    public function save_api_key() {
        // Check nonce
        if ( ! check_ajax_referer( 'postrocket_nonce', 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => __( 'Security check failed.', 'postrocket' ) ) );
        }

        // Get API key
        $api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( $_POST['api_key'] ) : '';

        // Save API key
        $api = new PostRocket_API();
        $result = $api->save_api_key( $api_key );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        } else {
            wp_send_json_success( array( 'message' => __( 'API key saved successfully.', 'postrocket' ) ) );
        }
    }

    /**
     * Verify API key.
     *
     * @since    1.0.0
     */
    public function verify_api_key() {
        // Check nonce
        if ( ! check_ajax_referer( 'postrocket_nonce', 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => __( 'Security check failed.', 'postrocket' ) ) );
        }

        // Verify API key
        $api = new PostRocket_API();
        $result = $api->verify_api_key();

        if ( $result['status'] === 'success' ) {
            wp_send_json_success( array( 'message' => $result['message'] ) );
        } else {
            wp_send_json_error( array( 'message' => $result['message'] ) );
        }
    }

    /**
     * Delete duplicate jobs.
     *
     * @since    1.0.0
     */
    public function delete_duplicate_jobs() {
        // Check nonce
        if ( ! check_ajax_referer( 'postrocket_nonce', 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => __( 'Security check failed.', 'postrocket' ) ) );
        }

        // Check if API key is valid
        $api = new PostRocket_API();
        if ( ! $api->validate_api_key() ) {
            wp_send_json_error( array( 'message' => __( 'Valid API key is required to use this feature.', 'postrocket' ) ) );
        }

        // Get all jobs
        $args = array(
            'post_type'      => 'job_listing',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'meta_query'     => array(
                array(
                    'key'     => '_postrocket_duplicate',
                    'value'   => '1',
                    'compare' => '=',
                ),
            ),
        );

        $jobs = get_posts( $args );
        $deleted_count = 0;

        foreach ( $jobs as $job ) {
            wp_delete_post( $job->ID, true );
            $deleted_count++;
        }

        wp_send_json_success( array(
            'message' => sprintf( __( '%d duplicate jobs deleted successfully.', 'postrocket' ), $deleted_count ),
            'count'   => $deleted_count,
        ) );
    }
}
