<?php
/**
 * Provide a admin area view for the plugin bulk operations page.
 *
 * @since      1.0.0
 * @package    PostRocket
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

// Get API instance
$api = new PostRocket_API();
$api_key_status = $api->validate_api_key();
?>

<div class="wrap postrocket-admin">
    <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
    
    
    <?php if ( ! $api_key_status ) : ?>
        <div class="postrocket-message postrocket-message-error">
            <p><?php esc_html_e( 'Valid API key is required to use bulk operations. Please enter your API key in the API Settings tab of the Job Manager page.', 'postrocket' ); ?></p>
        </div>
    <?php endif; ?>
    
    <div class="postrocket-bulk-operations">
        <!-- Delete Duplicate Jobs -->
        <div class="postrocket-card">
            <div class="postrocket-card-header">
                <h2><?php esc_html_e( 'Delete All Duplicate Jobs', 'postrocket' ); ?></h2>
            </div>
            <div class="postrocket-card-content">
                <p><?php esc_html_e( 'This operation will permanently delete all jobs that were created using the Job Duplicator.', 'postrocket' ); ?></p>
                <div class="postrocket-form-row">
                    <button type="button" id="delete-duplicate-jobs" class="button button-primary" <?php echo $api_key_status ? '' : 'disabled'; ?>>
                        <?php esc_html_e( 'Delete All Duplicate Jobs', 'postrocket' ); ?>
                    </button>
                </div>
                <div id="delete-duplicate-jobs-result"></div>
            </div>
        </div>
        
        <!-- Delete Expired Jobs -->
        <div class="postrocket-card">
            <div class="postrocket-card-header">
                <h2><?php esc_html_e( 'Delete All Expired Jobs', 'postrocket' ); ?></h2>
            </div>
            <div class="postrocket-card-content">
                <p><?php esc_html_e( 'This operation will permanently delete all jobs that have expired.', 'postrocket' ); ?></p>
                <div class="postrocket-form-row">
                    <button type="button" id="delete-expired-jobs" class="button button-primary" <?php echo $api_key_status ? '' : 'disabled'; ?>>
                        <?php esc_html_e( 'Delete All Expired Jobs', 'postrocket' ); ?>
                    </button>
                </div>
                <div id="delete-expired-jobs-result"></div>
            </div>
        </div>
        
        <!-- Delete All Jobs -->
        <div class="postrocket-card">
            <div class="postrocket-card-header">
                <h2><?php esc_html_e( 'Delete All Jobs', 'postrocket' ); ?></h2>
            </div>
            <div class="postrocket-card-content">
                <p class="postrocket-warning"><?php esc_html_e( 'WARNING: This operation will permanently delete ALL job listings. This action cannot be undone.', 'postrocket' ); ?></p>
                <div class="postrocket-form-row">
                    <button type="button" id="delete-all-jobs" class="button button-danger" <?php echo $api_key_status ? '' : 'disabled'; ?>>
                        <?php esc_html_e( 'Delete All Jobs', 'postrocket' ); ?>
                    </button>
                </div>
                <div id="delete-all-jobs-result"></div>
            </div>
        </div>
    </div>
</div>
