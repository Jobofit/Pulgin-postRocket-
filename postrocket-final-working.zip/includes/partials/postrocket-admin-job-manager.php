<?php
/**
 * Provide a admin area view for the plugin job manager page.
 *
 * @since      1.0.0
 * @package    PostRocket
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

// Get job duplicator instance
$job_duplicator = new PostRocket_Job_Duplicator();

// Get API instance
$api = new PostRocket_API();

// Get jobs for dropdown
$jobs = $job_duplicator->get_jobs_for_dropdown();

// Get companies for dropdown
$companies = $job_duplicator->get_companies_for_dropdown();

// Get settings
$hide_duplicates = get_option( 'postrocket_hide_duplicates', 'no' );
$noindex_duplicates = get_option( 'postrocket_noindex_duplicates', 'no' );

// Get API key status
$api_key = $api->get_api_key();
$api_key_status = $api->validate_api_key();

// Get active tab
$active_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'job-duplicator';
?>

<div class="wrap postrocket-admin">
    <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
    
    
    <h2 class="nav-tab-wrapper">
        <a href="?page=postrocket-job-manager&tab=job-duplicator" class="nav-tab <?php echo $active_tab === 'job-duplicator' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e( 'Job Duplicator', 'postrocket' ); ?>
        </a>
        <a href="?page=postrocket-job-manager&tab=visibility-settings" class="nav-tab <?php echo $active_tab === 'visibility-settings' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e( 'Visibility Settings', 'postrocket' ); ?>
        </a>
        <a href="?page=postrocket-job-manager&tab=api-settings" class="nav-tab <?php echo $active_tab === 'api-settings' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e( 'API Settings', 'postrocket' ); ?>
        </a>
    </h2>
    
    <div class="postrocket-tab-content">
        <?php if ( $active_tab === 'job-duplicator' ) : ?>
            <!-- Job Duplicator Tab -->
            <div class="postrocket-card">
                <div class="postrocket-card-header">
                    <h2><?php esc_html_e( 'Job Duplicator', 'postrocket' ); ?></h2>
                </div>
                <div class="postrocket-card-content">
                    <form id="postrocket-job-duplicator-form">
                        <?php wp_nonce_field( 'postrocket_nonce', 'nonce' ); ?>
                        
                        <div class="postrocket-form-row">
                            <label for="job_id"><?php esc_html_e( 'Select Base Job', 'postrocket' ); ?></label>
                            <select id="job_id" name="job_id" required>
                                <option value=""><?php esc_html_e( 'Select a job', 'postrocket' ); ?></option>
                                <?php foreach ( $jobs as $job ) : ?>
                                    <option value="<?php echo esc_attr( $job['id'] ); ?>">
                                        <?php echo esc_html( $job['title'] ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="postrocket-form-row">
                            <label for="company_id"><?php esc_html_e( 'Select Company (Optional)', 'postrocket' ); ?></label>
                            <select id="company_id" name="company_id">
                                <option value=""><?php esc_html_e( 'Use original company', 'postrocket' ); ?></option>
                                <?php foreach ( $companies as $company ) : ?>
                                    <option value="<?php echo esc_attr( $company['id'] ); ?>">
                                        <?php echo esc_html( $company['name'] ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="postrocket-form-row">
                            <label><?php esc_html_e( 'Mode Selection', 'postrocket' ); ?></label>
                            <div class="postrocket-radio-group">
                                <label class="postrocket-radio">
                                    <input type="radio" id="job-duplicator-mode-manual" name="job-duplicator-mode" value="manual" checked>
                                    <span><?php esc_html_e( 'Manual Mode', 'postrocket' ); ?></span>
                                </label>
                                <label class="postrocket-radio">
                                    <input type="radio" id="job-duplicator-mode-auto" name="job-duplicator-mode" value="auto">
                                    <span><?php esc_html_e( 'Auto Mode', 'postrocket' ); ?></span>
                                </label>
                            </div>
                            <p class="description">
                                <?php esc_html_e( 'Manual Mode: Enter locations manually. Auto Mode: Select from saved location lists.', 'postrocket' ); ?>
                            </p>
                        </div>
                        
                        <div class="postrocket-form-row postrocket-manual-mode">
                            <label for="locations"><?php esc_html_e( 'Enter Locations (comma separated)', 'postrocket' ); ?></label>
                            <textarea id="locations" name="locations" rows="5" placeholder="<?php esc_attr_e( 'Enter locations (e.g., Bangalore, Hyderabad)', 'postrocket' ); ?>"></textarea>
                            <div class="postrocket-character-counter">
                                <span id="locations-counter">0</span>/50 locations
                            </div>
                            <p class="description">
                                <?php esc_html_e( 'Enter up to 50 locations separated by commas. Each location will create a duplicate of the selected job.', 'postrocket' ); ?>
                            </p>
                        </div>
                        
                        <div class="postrocket-form-row postrocket-auto-mode" style="display: none;">
                            <label for="location_list_key"><?php esc_html_e( 'Select Stored Locations', 'postrocket' ); ?></label>
                            <select id="location_list_key" name="location_list_key" multiple>
                                <?php 
                                $location_manager = new PostRocket_Location_Manager();
                                $location_lists = $location_manager->get_location_lists();
                                foreach ( $location_lists as $key => $list ) : 
                                ?>
                                    <option value="<?php echo esc_attr( $key ); ?>">
                                        <?php echo esc_html( $list['name'] . ' (' . count( $list['locations'] ) . ' locations)' ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description">
                                <?php esc_html_e( 'Select one or more location lists. Each location will create a duplicate of the selected job. Maximum 50 locations allowed in total.', 'postrocket' ); ?>
                            </p>
                            <?php if ( empty( $location_lists ) ) : ?>
                                <p class="description">
                                    <?php esc_html_e( 'No location lists found. Please add locations in the Location.', 'postrocket' ); ?>
                                </p>
                            <?php endif; ?>
                        </div>
                        
                        <div class="postrocket-form-row">
                            <div id="postrocket-loading-container" style="display: none;">
                                <div class="postrocket-loading-spinner"></div>
                                <div id="postrocket-loading-text">Processing...</div>
                            </div>
                        </div>
                        
                        <div class="postrocket-form-row">
                            <button type="submit" class="button button-primary">
                                <?php esc_html_e( 'Duplicate Jobs', 'postrocket' ); ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
        <?php elseif ( $active_tab === 'visibility-settings' ) : ?>
            <!-- Visibility Settings Tab -->
            <div class="postrocket-card">
                <div class="postrocket-card-header">
                    <h2><?php esc_html_e( 'Visibility Settings', 'postrocket' ); ?></h2>
                </div>
                <div class="postrocket-card-content">
                    <form id="postrocket-visibility-settings-form">
                        <?php wp_nonce_field( 'postrocket_nonce', 'nonce' ); ?>
                        
                        <div class="postrocket-form-row">
                            <label for="hide_duplicates">
                                <input type="checkbox" id="hide_duplicates" name="hide_duplicates" value="yes" <?php checked( $hide_duplicates, 'yes' ); ?>>
                                <?php esc_html_e( 'Hide duplicate jobs from frontend', 'postrocket' ); ?>
                            </label>
                            <p class="description">
                                <?php esc_html_e( 'When enabled, duplicated jobs will not appear in frontend job listings.', 'postrocket' ); ?>
                            </p>
                        </div>
                        
                        <div class="postrocket-form-row">
                            <label for="noindex_duplicates">
                                <input type="checkbox" id="noindex_duplicates" name="noindex_duplicates" value="yes" <?php checked( $noindex_duplicates, 'yes' ); ?>>
                                <?php esc_html_e( 'Add noindex meta tag to duplicated jobs', 'postrocket' ); ?>
                            </label>
                            <p class="description">
                                <?php esc_html_e( 'When enabled, duplicated jobs will have a noindex meta tag to prevent search engines from indexing them.', 'postrocket' ); ?>
                            </p>
                        </div>
                        
                        <div class="postrocket-form-row">
                            <button type="submit" class="button button-primary">
                                <?php esc_html_e( 'Save Settings', 'postrocket' ); ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
        <?php elseif ( $active_tab === 'api-settings' ) : ?>
            <!-- API Settings Tab -->
            <div class="postrocket-card">
                <div class="postrocket-card-header">
                    <h2><?php esc_html_e( 'API Settings', 'postrocket' ); ?></h2>
                </div>
                <div class="postrocket-card-content">
                    <form id="postrocket-api-settings-form">
                        <?php wp_nonce_field( 'postrocket_nonce', 'nonce' ); ?>
                        
                        <div class="postrocket-form-row">
                            <label for="api_key"><?php esc_html_e( 'API Key', 'postrocket' ); ?></label>
                            <input type="text" id="api_key" name="api_key" value="<?php echo esc_attr( $api_key ); ?>" class="regular-text">
                            <p class="description">
                                <?php esc_html_e( 'Enter your API key for PostRocket. The API key will be encrypted and tied to your domain for security. This key can only be used on one website.', 'postrocket' ); ?>
                            </p>
                        </div>
                        
                        <div class="postrocket-form-row">
                            <div class="postrocket-api-status">
                                <?php if ( $api_key_status ) : ?>
                                    <span class="postrocket-status-valid">
                                        <span class="dashicons dashicons-yes"></span>
                                        <?php esc_html_e( 'API Key is valid', 'postrocket' ); ?>
                                    </span>
                                <?php else : ?>
                                    <span class="postrocket-status-invalid">
                                        <span class="dashicons dashicons-no"></span>
                                        <?php esc_html_e( 'API Key is invalid or missing', 'postrocket' ); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div id="postrocket-api-message"></div>
                        </div>
                        
                        <div class="postrocket-form-row postrocket-button-row">
                            <button type="submit" class="button button-primary">
                                <?php esc_html_e( 'Save API Key', 'postrocket' ); ?>
                            </button>
                            <button type="button" id="verify-api-key" class="button button-secondary">
                                <?php esc_html_e( 'Verify API Key', 'postrocket' ); ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
