<?php
/**
 * Provide a admin area view for the plugin help and support page.
 *
 * @since      1.0.0
 * @package    PostRocket
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

// Redirect to skillonzo.co.in
?>
<script type="text/javascript">
    window.open('https://skillonzo.co.in', '_blank');
    window.location.href = '<?php echo esc_url( admin_url( 'admin.php?page=postrocket' ) ); ?>';
</script>

<div class="wrap postrocket-admin">
    <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
    
    <div class="postrocket-help-support">
        <div class="postrocket-card">
            <div class="postrocket-card-header">
                <h2><?php esc_html_e( 'Help & Support', 'postrocket' ); ?></h2>
            </div>
            <div class="postrocket-card-content">
                <p><?php esc_html_e( 'Redirecting to Skillonzo support website...', 'postrocket' ); ?></p>
                <p><?php esc_html_e( 'If you are not redirected automatically, please click the button below:', 'postrocket' ); ?></p>
                <p>
                    <a href="https://skillonzo.co.in" target="_blank" class="button button-primary">
                        <?php esc_html_e( 'Visit Support Website', 'postrocket' ); ?>
                    </a>
                </p>
            </div>
        </div>
    </div>
</div>
