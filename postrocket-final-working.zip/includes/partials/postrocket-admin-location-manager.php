<?php
/**
 * Provide a admin area view for the plugin location manager page.
 *
 * @since      1.0.0
 * @package    PostRocket
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

// Get saved locations
$saved_locations = get_option( 'postrocket_saved_locations', array() );
?>

<div class="wrap postrocket-admin">
    <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
    
    
    <div class="postrocket-location-manager">
        <!-- Location Card -->
        <div class="postrocket-card">
            <div class="postrocket-card-header">
                <h2><?php esc_html_e( 'Location', 'postrocket' ); ?></h2>
            </div>
            <div class="postrocket-card-content">
                <form id="postrocket-location-manager-form">
                    <?php wp_nonce_field( 'postrocket_nonce', 'nonce' ); ?>
                    
                    <div class="postrocket-form-row">
                        <label for="location_list_name"><?php esc_html_e( 'Location List Name', 'postrocket' ); ?></label>
                        <input type="text" id="location_list_name" name="location_list_name" required>
                        <p class="description">
                            <?php esc_html_e( 'Enter a name for this location list.', 'postrocket' ); ?>
                        </p>
                    </div>
                    
                    <div class="postrocket-form-row">
                        <label for="locations"><?php esc_html_e( 'Locations (comma separated)', 'postrocket' ); ?></label>
                        <textarea id="locations" name="locations" rows="5" placeholder="Mumbai, Pune, Delhi" required></textarea>
                        <p class="description">
                            <?php esc_html_e( 'Enter locations separated by commas. Maximum 50 locations allowed. Spaces will be automatically trimmed, and duplicates will be ignored.', 'postrocket' ); ?>
                        </p>
                        <div class="postrocket-character-counter">
                            <span id="locations-counter">0</span>/50 locations
                        </div>
                    </div>
                    
                    <div class="postrocket-form-row">
                        <button type="submit" class="button button-primary">
                            <?php esc_html_e( 'Save Locations', 'postrocket' ); ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Saved Locations Card -->
        <div class="postrocket-card">
            <div class="postrocket-card-header">
                <h2><?php esc_html_e( 'Saved Location Lists', 'postrocket' ); ?></h2>
            </div>
            <div class="postrocket-card-content">
                <?php if ( ! empty( $saved_locations ) ) : ?>
                    <table class="postrocket-table" id="postrocket-saved-locations-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'List Name', 'postrocket' ); ?></th>
                                <th><?php esc_html_e( 'Locations', 'postrocket' ); ?></th>
                                <th><?php esc_html_e( 'Count', 'postrocket' ); ?></th>
                                <th><?php esc_html_e( 'Actions', 'postrocket' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $saved_locations as $key => $location_list ) : ?>
                                <tr data-key="<?php echo esc_attr( $key ); ?>">
                                    <td><?php echo esc_html( $location_list['name'] ); ?></td>
                                    <td><?php echo esc_html( implode( ', ', $location_list['locations'] ) ); ?></td>
                                    <td><?php echo esc_html( count( $location_list['locations'] ) ); ?></td>
                                    <td>
                                        <button type="button" class="button button-small postrocket-delete-location-list">
                                            <?php esc_html_e( 'Delete', 'postrocket' ); ?>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else : ?>
                    <p><?php esc_html_e( 'No location lists saved yet.', 'postrocket' ); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
